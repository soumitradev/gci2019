# License
These designs were originaly made by [Soumitra Shewale](https://github.com/soumitradev) and were published in the CC BY-NC-SA 4.0 license.

All images used were in Public Domain, except for the Julia Logos (different styles), the Julia logo font (MN Tamil/ MN Latin).

The external images used other than media from the [Julia graphics repository](https://github.com/JuliaLang/julia-logo-graphics) are:
- Font ["Comfortaa"](https://fonts.google.com/specimen/Comfortaa?selection.family=Comfortaa)
- [Python Logo file](https://commons.wikimedia.org/wiki/File:Python-logo-notext.svg)
- [C logo file](https://commons.wikimedia.org/wiki/File:The_C_Programming_Language_logo.svg)
- The ["Hello my name is"](https://commons.wikimedia.org/wiki/File:Hello_my_name_is_sticker.svg) image

All the above mentioned images and fonts are in Public Domain as of 13th December 2019, and their licenses can be verified by the hyperlinks provided.

These designs are licensed under the Creative Commons
["BY-NC-SA" 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/) License.
This means that you are free to:

- **Share** — copy and redistribute the material in any medium or format
- **Adapt** — remix, transform, and build upon the material

The licensor cannot revoke these freedoms as long as you follow the license terms:

- **Attribution** — You must give appropriate credit, provide a link to the license,
  and indicate if changes were made. You may do so in any reasonable manner, but not
  in any way that suggests the licensor endorses you or your use.
- **NonCommercial** — You may not use the material for commercial purposes.
- **ShareAlike** — If you remix, transform, or build upon the material, you must
  distribute your contributions under the same license as the original.
- **No additional restrictions** — You may not apply legal terms or technological
  measures that legally restrict others from doing anything the license permits.